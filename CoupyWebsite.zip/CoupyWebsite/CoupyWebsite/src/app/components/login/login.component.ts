import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { Router } from '@angular/router';
import { LoginValidatorService } from 'src/app/services/login-validator.service';
import { AuthService } from 'src/app/guards/auth.service';
import { AdminComponent } from '../admin/admin.component';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  email?: string;
  password?: string;
  clientType?: string;
  loginForm: FormGroup;
  
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  Clients: String[] = [
    this.clientType = "CUSTOMER", 
    this.clientType = "COMPANY",
    this.clientType = "ADMIN"
  ];
  client: object;
  selectedClientType = this.Clients[0];
  
  constructor(private formBuilder: FormBuilder ,private loggedIn: LoginValidatorService,  private auth: AuthService, private router: Router) {}

    // {email: new FormControl("",Validators.required), 
    // password: new FormControl("",Validators.required),
    // clientType: new FormControl("",Validators.required, Validators.minLength(6))
  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: [this.email, [Validators.required]],
      password: [this.password, [Validators.required, Validators.minLength(6)]],
      clientType:[this.clientType]
    });
  }

  get f() { return this.loginForm.controls; }

  firstClick() {
    this.loggedIn.firstClick();
  }
  adminLogin(admin:any) {
    this.router.navigateByUrl("/admin");
  }
  companyLogin(company:any) {
    this.router.navigateByUrl("/company");
  }
  customerLogin(customer:any) {
    this.router.navigateByUrl("/home");
  }
//   ClientController(clientType?: string) {
//     this.auth.ClientController(clientType)
ControlClientType() {

}
onSubmit(form: any):void {
    this.loggedIn.LoginController(form).subscribe(loggedIn => {
      form = loggedIn;
      this.auth.sendToken(this.f.email.value);  
      switch(this.f.clientType.value) {
        case "CUSTOMER":
         this.customerLogin(form);
        case "COMPANY":
         this.companyLogin(form);          
        case "ADMIN":
         this.adminLogin(form);
      }
      alert("{\"Welcome\":\"you are logged in\"}")
    console.log('you submitted value:', form);
  },err => {
    if (this.loginForm.valid && err instanceof HttpErrorResponse) {
      const errorMessages = new Array<{ propName: string; errors: string }>();
      if (err.status === 500) {
        alert("email or password were not found or were not matching, please check if you typed them correctly and try again" + errorMessages);
        this.auth.logout();    
      }
    }
  })
}
//       this.auth.sendToken(this.loginForm.value.email);
//       alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.loginForm.value))
//        this.router.navigate(["/admin"]);
//       return;
// }else
//   alert('the Email or Password you entered were inccorect please check if you typed them correctly and try again :-)\n\n' + JSON.stringify(this.loginForm.value))
//   }
// }

// }
}
