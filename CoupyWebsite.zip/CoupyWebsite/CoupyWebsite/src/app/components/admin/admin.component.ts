import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Company } from '../../models/company';
import { CompanyService } from '../../services/company.service';
import { Customer } from 'src/app/models/customer';
import { CustomerService } from 'src/app/services/customer.service';
import { Income } from 'src/app/models/income';
import { CouponsService } from 'src/app/services/coupons.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  searchText: string;

  addCompanyForm: FormGroup;
  updateCompanyForm:FormGroup;
  
  addCustomerForm: FormGroup;
  updateCustomerForm:FormGroup;
  public company:Company;
  public companies: Company[];
  public customer:Customer;
  public customers:Customer[];
  public income:Income;
  public incomes:Income[];
  public amount?:number;
  public transactionDate?:Date;
  public description?:string;
  public clientID?:string;
  public id?:number;
  public name?:string;
  public email?:string;
  public password?:string;
  public customerId?:number;
  public firstName?:string;
  public lastName?:string; 
  


  constructor(private formBuilder: FormBuilder, private companyService: CompanyService, private customerService:CustomerService, private couponService: CouponsService) { 
    this.company= new Company();
    this.customer= new Customer();
    // this.income=new Income();

    // this.companyService.getAllCompanies().subscribe(data => {
    //   data.forEach(company => {
    //     this.companies.push(company); 
        
    //   });
    // }); 
    
    // this.customerService.getAllCustomers().subscribe(data => {
    //   data.forEach(customer => {
    //     this.customers.push(customer);
        
    //   });
    // }); 
  }
  
  ngOnInit() {
    this.getCompanies();
    this.getCustomers();
    // this.getIncomes();
    // this.displayTotalIncome();
    // this.couponService.getAllIncomes().subscribe(income =>{
    //   this.incomes=income;
    //   console.log(income);
    // });
    this.income = ({id:this.id,name:this.name,transactionDate:this.transactionDate,description:this.description,amount:this.amount,clientID:this.clientID});
    // Companies Forms
    this.addCompanyForm = this.formBuilder.group({
      id: [this.id],
      name: [this.name],
      email: [this.email],
      password: [this.password],
    });

    this.updateCompanyForm = this.formBuilder.group({
      id: [this.id],
      name: [this.name],
      email: [this.email],
      password: [this.password],
    });


    // Customer Forms
    this.addCustomerForm = this.formBuilder.group({
      id: [this.customerId],
      firstName:[this.firstName],
      lastName:[this.lastName],
      email:[this.email],
      password:[this.password],
    });
    this.updateCustomerForm = this.formBuilder.group({
      id: [this.customerId],
      firstName:[this.firstName],
      lastName:[this.lastName],
      email:[this.email],
      password:[this.password],
    });

  }
  trackByIncomeId(index,income) {
    if(!income) return undefined;
    return income.id;
  }
  trackByCompanyId(index,company){
    if(!company) return undefined;
    return company.id;
  }

  trackByCustomersId(index1,customer){
    if(!customer) return undefined;
    return customer.id;

  }
  getCompanies():Company[] {
    this.companyService.getAllCompanies().subscribe(companies => {
      this.companies = companies;
    });
    return this.companies;
  }
  getCustomers():Customer[] {
    this.customerService.getAllCustomers().subscribe(customers =>{
      this.customers = customers;
    });
    return this.customers;
  }
  getIncomes():Income[] {
    this.couponService.getAllIncomes().subscribe(income =>{
      this.incomes=income;
    });
    return this.incomes;
  }
  getCompanyIncomes(companyID:number):Income[] {
    this.couponService.getAllCompanyIncomes(companyID).subscribe(income =>{
      this.incomes=income;
    });
    return this.incomes;
  }
  getCustomerIncomes(customerID:number):Income[] {
    this.couponService.getAllCustomerIncomes(customerID).subscribe(income =>{
      this.incomes=income;
    });
    return this.incomes;
  }

  displayUpdateCompany(company:Company) {
    this.company=company;
  }
  displayUpdateCustomer(customer:Customer) {
    this.customer=customer;
    this.id=customer.id;
    this.firstName=customer.firstName;
    this.lastName=customer.lastName;
    this.email=customer.email;
    this.password=customer.password;
  }
  navigateToCompanyOptions() {
    let OptionsMainCards = document.getElementsByClassName("Options") as HTMLCollectionOf<HTMLElement>;
    let companyOptionOnEnter = document.getElementsByClassName("Company1") as HTMLCollectionOf<HTMLElement>;
    let companyCRUD = document.getElementsByClassName("companyCRUD") as HTMLCollectionOf<HTMLElement>;
    let allCompanies = document.getElementsByClassName("allCompaniesContainer") as HTMLCollectionOf<HTMLElement>;
    let cardsCompany = document.getElementsByClassName("cardsCompany") as HTMLCollectionOf<HTMLElement>;
    // let CompanyIncomes = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;
    let CompanyIncomesWindow = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;


    companyOptionOnEnter[0].style.animationName = "navigate";
    companyOptionOnEnter[0].style.animationDuration = "1s";
    companyOptionOnEnter[0].style.animationTimingFunction = "ease-in both";
    
        // cardonLeave[i].style.animationName = "navigateRight"
        // cardonLeave[i].style.animationDuration = "1s";
      //RightAnimation
        // cardonLeave[i].style.animationName = "navigateLeft"
        // cardonLeave[i].style.animationDuration = "1s";

      setTimeout(() => {
        console.log("COMPANYYYYYYYYY");
        OptionsMainCards[0].style.display = "none";
        this.couponService.getAllIncomes().subscribe(income =>{
          this.incomes=income;
          // for(var a=0;a<CompanyIncomes.length;a++){
          //   CompanyIncomes[a].style.display = "none";
          // }
          CompanyIncomesWindow[0].style.display="-webkit-inline-flex";
        });
        // allCompanies[0].style.display = "block";
        // allCompanies[0].style.width = "100%";
        // allCompanies[0].style.height = "500px"
        companyCRUD[0].style.display = "flex";
        for(var i = 0; i<cardsCompany.length;i++){ 
          cardsCompany[i].style.display = "flex";
        }

        // this._router.navigate(['login']);

      }
      , 1000);
    }

    navigateToCustomerOptions() {
      let OptionsMainCards = document.getElementsByClassName("Options") as HTMLCollectionOf<HTMLElement>;
      let customerOptionOnEnter  = document.getElementsByClassName("Customer1") as HTMLCollectionOf<HTMLElement>;
      let customerCRUD = document.getElementsByClassName("customerCRUD") as HTMLCollectionOf<HTMLElement>;
      let cardsCustomer = document.getElementsByClassName("cardsCustomer") as HTMLCollectionOf<HTMLElement>;
      let CustomersIncomesWindow = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;
      customerOptionOnEnter[0].style.animationName = "navigate";
      customerOptionOnEnter[0].style.animationDuration = "1s";
      customerOptionOnEnter[0].style.animationTimingFunction = "ease-in both";
  
          // cardonLeave[i].style.animationName = "navigateRight"
          // cardonLeave[i].style.animationDuration = "1s";
        //RightAnimation
          // cardonLeave[i].style.animationName = "navigateLeft"
          // cardonLeave[i].style.animationDuration = "1s";
  
        setTimeout(() => {
          console.log("CUSTOMERRRRR");
          OptionsMainCards[0].style.display = "none";
          this.couponService.getAllIncomes().subscribe(income =>{
            this.incomes=income;
            CustomersIncomesWindow[0].style.display="-webkit-inline-flex";

          });
          customerCRUD[0].style.display = "flex";
          for(var i = 0; i<cardsCustomer.length;i++){ 
            cardsCustomer[i].style.display = "flex";
          }
    }
    , 1000);
    }

    onSubmitCompanyCreate(form:any) {
      this.companyService.createCompany(form).subscribe(company =>{
        form = company;
      });
      setTimeout(() => {
        this.getCompanies();
        
  }
  , 1000);
}
    getCompany(company:Company){
          this.companyService.getOneCompany(company).subscribe(companyID=>{
            company = companyID;
          });
        
        }
    onSubmitCompanyUpdate(form:Company) {
      this.companyService.updateCompany(form).subscribe(company =>{
        form = company;
      });
      setTimeout(() => {
        this.getCompanies();
        
  }
  , 1000);
}
    onSubmitCompanyDelete(form:Company) {
      this.companyService.deleteCompany(form).subscribe(company =>{
        form = company;
      });
      setTimeout(() => {
        this.getCompanies();
        
      }
      , 1000);
    }

    onSubmitCustomerCreate(form:any) {
      this.customerService.createCustomer(form).subscribe(customer =>{
        form=customer;
      });
      setTimeout(() => {
      var index:number;
      for(var customer of this.customers) {
        if(customer.id == this.customer.id) {
          index = this.customers.indexOf(customer);
        }
      }       
      
      this.customers[index] = this.customer;
      this.getCustomers();
      alert("Customer " + form.firstName +" " + form.lastName + "has been created");
    }
      , 50);
    }
    getCustomer(customer:Customer):Customer{
      this.customerService.getOneCustomer(customer).subscribe(customer =>{
        this.customer=customer;
      });
      return this.customer;
    }
    onSubmitCustomerUpdate(customer1:any) {
      customer1.firstName=this.customer.firstName;
      customer1.lastName=this.customer.lastName;
      customer1.email=this.customer.email;
      this.customerService.updateCustomer(customer1).subscribe(customer=>{
        customer1=customer;
      });
      setTimeout(() => {
        // this.getCustomers();
      // this.customer= this.getCustomer(customer1)
      var index:number;
      for(var customer of this.customers) {
        if(customer.id == this.customer.id) {
          index = this.customers.indexOf(customer);
        }
      }       
      
      this.customers[index] = this.customer;
      this.getCustomers();
    }
      , 50);
    }
    onSubmitCustomerDelete(customerId:number) {
      this.customerService.deleteCustomer(customerId).subscribe(customerID =>{
      });
      setTimeout(() => {
        this.getCustomers();
        
      }
      , 1000);
    }
    navigateToCompany(company:Company) {
      let companyCRUD = document.getElementsByClassName("companyCRUD") as HTMLCollectionOf<HTMLElement>;
      let gotCompany = document.getElementsByClassName("gotCompany") as HTMLCollectionOf<HTMLElement>;
      let CompanyIncomes = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;
      companyCRUD[0].style.animationName = "navigate";
      companyCRUD[0].style.animationDuration = "1s";
      companyCRUD[0].style.animationTimingFunction = "ease-in both";
      setTimeout(() => {
        this.company=company;
        console.log(this.company);
       
          let ClientID:string;
          ClientID="Co";
          for(var Income of this.incomes) {
            this.incomes=this.incomes.filter(income => Income!=income);

            // this.incomes=this.incomes.filter(income => (ClientID+this.company.id)!=Income.clientID);
          }
          this.couponService.getAllCompanyIncomes(this.company.id).subscribe(income =>{
            this.incomes=income;
          });
            // this.incomes.push(income);

        companyCRUD[0].style.display = "none";
        gotCompany[0].style.display = "block";
  }
  , 1000);
  }

    onClickGoOutOfCompany() {
      let companyCRUD = document.getElementsByClassName("companyCRUD") as HTMLCollectionOf<HTMLElement>;
      let gotCompany = document.getElementsByClassName("gotCompany") as HTMLCollectionOf<HTMLElement>;
      gotCompany[0].style.animationName = "navigate";
      gotCompany[0].style.animationDuration = "1s";
      gotCompany[0].style.animationTimingFunction = "ease-in both";
      setTimeout(() => {
        this.couponService.getAllIncomes().subscribe(income =>{
          this.incomes=income;
        });
        gotCompany[0].style.display = "none";
        companyCRUD[0].style.display = "flex";
    }
    , 1000);
  }

  navigateToCustomer(customer:Customer) {
    let customerCRUD = document.getElementsByClassName("customerCRUD") as HTMLCollectionOf<HTMLElement>;
    let gotCustomer = document.getElementsByClassName("gotCustomer") as HTMLCollectionOf<HTMLElement>;
    let CompanyIncomes = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;
    customerCRUD[0].style.animationName = "navigate";
    customerCRUD[0].style.animationDuration = "1s";
    customerCRUD[0].style.animationTimingFunction = "ease-in both";
    setTimeout(() => {
      this.customer=customer;
      console.log(this.customer);
    
        let ClientID:string;
        ClientID="Cu";
          for(var Income of this.incomes) {
            this.incomes=this.incomes.filter(income => Income!=income);
          }
      
          this.couponService.getAllCustomerIncomes(this.customer.id).subscribe(income =>{
            this.incomes=income;
            console.log(income);
            console.log(this.customer.id);


          });
      customerCRUD[0].style.display = "none";
      gotCustomer[0].style.display = "block";
}
, 1000);
  }

  onClickGoOutOfCustomer() {
    let customerCRUD = document.getElementsByClassName("customerCRUD") as HTMLCollectionOf<HTMLElement>;
    let gotCustomer = document.getElementsByClassName("gotCustomer") as HTMLCollectionOf<HTMLElement>;
    gotCustomer[0].style.animationName = "navigate";
    gotCustomer[0].style.animationDuration = "1s";
    gotCustomer[0].style.animationTimingFunction = "ease-in both";
    console.log(this.customer);

    setTimeout(() => {
      this.couponService.getAllIncomes().subscribe(income =>{
        this.incomes=income;
      });
    gotCustomer[0].style.display = "none";
      customerCRUD[0].style.display = "flex";
  }
  , 1000);
}
getTotal() {
  var i;
  var total:number;
  this.couponService.getAllIncomes().subscribe(income =>{
    this.incomes=income;
  for(i=0;i<this.incomes.length;i++) {
   total = this.incomes[i].amount + total;
  }
  console.log(total);
  return total;
  });
}
displayTotalIncome() {
  let totalIncome = document.getElementsByClassName("IncomeCard all") as HTMLCollectionOf<HTMLElement>;
  for(var i=0;i<totalIncome.length;i++) {
    totalIncome[i].style.display= "flex";
  }
}



}
