import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.css']
})
export class LayoutComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }
  //getUrl()
//{
  //return "url('https://blog.hdwallsource.com/wp-content/uploads/2016/03/big-library-wallpaper-50365-52056-hd-wallpapers.jpg')";
//}

}
