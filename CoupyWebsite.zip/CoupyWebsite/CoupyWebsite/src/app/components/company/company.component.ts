import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Coupon } from 'src/app/models/coupon';
import { CouponsService } from 'src/app/services/coupons.service';
import {formatDate} from '@angular/common';
import { CompanyService } from 'src/app/services/company.service';
import { Company } from 'src/app/models/company';
import { Catagory } from 'src/app/models/catagory';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { PositionStrategy } from '@angular/cdk/overlay';
import { MatOption } from '@angular/material';
import { timingSafeEqual } from 'crypto';
import { runInThisContext } from 'vm';
import { Income } from 'src/app/models/income';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css']
})
export class CompanyComponent implements OnInit {

  couponsFilterControl=new FormControl();
  filteredOptions: Observable<Coupon[]>
  searchText:string;
  addCouponForm: FormGroup;
  updateCouponForm: FormGroup;
  company:Company;
  public coupon: Coupon;
  public coupons:Coupon[];
  catagory1:Catagory;
  catagories:Catagory[];
  object:{}
  public id?:number;
  public companyID?:number;
  public catagory?:string;
  public title?:string;
  public couponDescription?:string; 
  public startDate? = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  public endDate? = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  public amount?:number;
  public price?:number;
  public image?:string;
  public income:Income;
  public incomes:Income[];
  public transactionDate?:Date;
  public description?:string;
  public clientID?:string;
  public name?:string;
  selectedCoupon?:String;
  SearchCoupon?:string;
  changed:boolean = false;
  ResetSearch:boolean=false;
  index:number;
  
  constructor(private formBuilder: FormBuilder, private couponService: CouponsService, private companyService: CompanyService) {
    this.coupons= new Array<Coupon>();
    // this.incomes= new Array<Income>();
    this.startDate;
    this.coupon = new Coupon();
    this.company = new Company();
    // this.income = new Income();
    this.getCompanyProfile();
    
    
    this.couponService.getAllCompanyCoupons().subscribe(data => {
      data.forEach(couponElement => {
        this.coupons.push(couponElement); 
        return this.coupons;
      });
    }); 
    this.couponService.getAllIncomeBy().subscribe(data => {
      this.incomes = data;
    });
    //   this.couponService.getAllIncomeBy().subscribe(data => {
  //     data.forEach(Income => {
    //       this.incomes.push(Income); 
    //       return this.incomes;
    //   });
    // });
  }
  
  ngOnInit() {
    this.income = ({id:this.id,name:this.name,transactionDate:this.transactionDate,description:this.description,amount:this.amount,clientID:this.clientID});

    this.couponService.getAllIncomeBy().subscribe(data => {
     this.incomes=data;
     console.log(this.incomes)
    });
    // this.getAllCompanyCoupons();
    this.getAllCatagories();
    this.addCouponForm = this.formBuilder.group({
      id: [this.id],
      companyID: [this.companyID],
      catagory: [this.catagory],
      title: [this.title],
      couponDescription: [this.couponDescription],
      startDate: [this.startDate],
      endDate: [this.endDate],
      amount: [this.amount],
      price: [this.price], 
      image: [this.image],
    });
    this.updateCouponForm = this.formBuilder.group({
      id:[this.id],
      companyID: [this.companyID],
      catagory: [this.catagory],
      title:[this.title],
      startDate: [this.startDate],
      endDate:[this.endDate],
      amount:[this.amount],
      price:[this.price]
    });
    this.filteredOptions = this.couponsFilterControl.valueChanges
      .pipe(
        startWith(''),
        map(value => typeof value === 'string' ? value : value.title),
        map(title =>title ? this._filter(title): this.coupons.slice()),
      );
  }
  
  set isDisabled(value: boolean) {
    this.addCouponForm.get(this.startDate).disable();
    this.isDisabled = value;
    if(value) {
      this.addCouponForm.controls[this.startDate].disable();
    } else {
      this.addCouponForm.controls[this.startDate].enable();
    }
  }
  
  get f() { return this.addCouponForm.controls; }

  displayFn(coupon?: Coupon): string | undefined {
    return coupon ? coupon.title : undefined;
  }
  
  private _filter(value: string): Coupon[] {
    const filterValue = value.toLowerCase();
  
      return this.coupons.filter(coupon => coupon.title.toLowerCase().indexOf(filterValue) === 0);
  }
  trackByCouponId(index, coupon){
    if(!this.coupon) return undefined;
    return coupon.id;
}
trackByIncomeId(index,income) {
  if(!income) return undefined;
  return income.id;
}

  pushCouponOnOpen() {
    console.log("mouseenter")
    // console.log("mouseenter" +this.coupons[0].id);
    var width = "250px";
    var i:number;
    let cardOnOpen = document.getElementsByClassName("container") as HTMLCollectionOf<HTMLElement>;
    if (cardOnOpen.length != 0) {
      // cardOnOpen[0].style.width = "400px"
      // cardOnOpen[0].style.height = "500px"
      cardOnOpen[0].style.width = "800px"
      cardOnOpen[0].style.height = "900px"
      cardOnOpen[0].style.left = "200px"
      cardOnOpen[0].style.transitionDuration = "0.6s";
      cardOnOpen[0].style.transition = "1.5"
      // document.getElementsByClassName("container").style.width = width;
    }
  }
  pushCouponOnLeave() {
    let cardonLeave = document.getElementsByClassName("container") as HTMLCollectionOf<HTMLElement>;
    console.log(cardonLeave.length)
    var i:number;
    // cardonLeave[index].style.width = "170px"
    // cardonLeave[index].style.height = "220px"
    cardonLeave[0].style.left ="0px"
    cardonLeave[0].style.width = "300px"
    cardonLeave[0].style.height = "400px"
    cardonLeave[0].style.transitionDuration = "0.6s";
    
  }
  DisplayAdd() {
    let cardsCompany = document.getElementsByClassName("cardsCompany") as HTMLCollectionOf<HTMLElement>;
    let allCompanies = document.getElementsByClassName("allCompanies") as HTMLCollectionOf<HTMLElement>;
    let couponAddForm = document.getElementsByClassName("container") as HTMLCollectionOf<HTMLElement>;
    // let Coupon = document.getElementsByClassName("CouponsContent") as HTMLCollectionOf<HTMLElement>;
    let Options = document.getElementsByClassName("Options") as HTMLCollectionOf<HTMLElement>;
    let box = document.getElementsByClassName("box") as HTMLCollectionOf<HTMLElement>;
    let CompanyIncomesWindow = document.getElementsByClassName("IncomeCards") as HTMLCollectionOf<HTMLElement>;

    // if(Coupon.length>=1) {

    //   Coupon[0].style.display="none";
    // }
    // cardsCompany[0].style.display="none";
    CompanyIncomesWindow[0].style.display="none";
    allCompanies[0].style.display="none";
    couponAddForm[0].style.display="flex";
    Options[0].style.display="none";
    for(var i=0; i>box.length;i++) {

      box[0].style.display="none";
    }


  }
  displayReadCoupon(){
    let ReadOption = document.getElementsByClassName("box ReadOption") as HTMLCollectionOf<HTMLElement>;
    let ReadOptionHeader = document.getElementsByClassName("box ReadOption h1") as HTMLCollectionOf<HTMLElement>;

    let Read = document.getElementsByClassName("box Read") as HTMLCollectionOf<HTMLElement>;
    ReadOption[0].style.display= "none";



    Read[0].style.display= "flex";

    Read[0].style.width ="100%";
    Read[0].style.height ="auto";


  }
  displayCoupon( Coupon:Coupon) {
    let Coupons = document.getElementsByClassName("cardsCompany") as HTMLCollectionOf<HTMLElement>;
    // let Coupon = document.getElementsByClassName("CouponsContent") as HTMLCollectionOf<HTMLElement>;
    // console.log(coupon + " " + selectedCoupon);
    let MockCoupon:Coupon;
    MockCoupon=Coupon;
    var MockSearchCoupon:string;
    MockSearchCoupon=this.SearchCoupon;
    console.log(this.SearchCoupon);
    console.log(MockCoupon);
    for(var i=0;i>Coupons.length;i++) {
    Coupons[i].style.animationName = "navigate"
    Coupons[i].style.animationDuration = "1s"
    Coupons[i].style.animationTimingFunction = "ease-in both"
    }
    
    for(var coupon of this.coupons) {
      this.coupons=this.coupons.filter(obj => Coupon!=coupon);
    }
    this.coupons.push(Coupon);
    this.changed=true;
    console.log(this.coupons);
    // var index=this.coupons.indexOf(Coupon);
    for(var a=0;a<Coupons.length;a++) {
    Coupons[a].style.alignContent="center";
    Coupons[a].style.marginLeft="35%";
    // Coupons[i].style.lineHeight="3em";

    }
    setTimeout(() => {
        // return this.coupons;
        // Coupon[0].style.animationName = "navigate"
        // Coupon[0].style.animationDuration = "1s"
        // Coupon[0].style.animationTimingFunction = "ease-in both"
        // Coupon[0].style.animationDirection = "backwards"
        // Coupons[i].style.display= "none";

      }
    , 10);
  }
  resetSearch(){
    this.coupons=this.getAllCompanyCoupons().map(x => x, this.coupons);
  this.coupons.shift();
  }
  displayCouponUpdate() {
    let UpdateOption = document.getElementsByClassName("box UpdateOption") as HTMLCollectionOf<HTMLElement>;
    let Update = document.getElementsByClassName("box update") as HTMLCollectionOf<HTMLElement>;
    UpdateOption[0].style.display= "none";

    Update[0].style.display= "flex";
    
    Update[0].style.width ="100%";
    Update[0].style.height ="auto";
    
  }
  displayUpdateCoupon(coupon:Coupon) {
    this.coupon=coupon;
    this.id=coupon.id;
    this.companyID=coupon.id;
    this.catagory=coupon.catagory;
    console.log(this.catagory);
    this.title=coupon.title;
    this.startDate=formatDate(new Date(coupon.startDate), 'yyyy-MM-dd', 'en');
    this.endDate=formatDate(new Date(coupon.endDate), 'yyyy-MM-dd', 'en');
    this.amount=coupon.amount;
    this.price=coupon.price
    let UpdateOption = document.getElementsByClassName("box UpdateOption") as HTMLCollectionOf<HTMLElement>;
    let Update = document.getElementsByClassName("box update") as HTMLCollectionOf<HTMLElement>;
    UpdateOption[0].style.display= "none";

    Update[0].style.display= "flex";
    
    Update[0].style.width ="100%";
    Update[0].style.height ="auto";
  }
  DisplayCouponRemove() {

  }
  removeCoupon(couponToRemove:Coupon) {
    alert("You are about to delete coupon " + couponToRemove.id);
    this.couponService.removeCoupon(couponToRemove).subscribe(coupon => {
      couponToRemove=coupon
    });
    location.reload(true);
  }
  
  onSubmit(form:any):void {
    console.log(JSON.stringify(form));
    this.couponService.addCoupon(form).subscribe(coupons => {
      form = coupons;
    });
    location.reload(true);
  }
  onSubmitCouponUpdate(form:any){
    console.log(JSON.stringify(form));
    let Coupons = document.getElementsByClassName("cardsCompany") as HTMLCollectionOf<HTMLElement>;
    let Coupons1 = document.getElementsByClassName("cardsCompany") as HTMLSelectElement;

    this.couponService.updateCoupon(form).subscribe(coupon =>{
      form = coupon;
    });
    setTimeout(() => {
    this.coupon = this.getOneCompanyCoupon(form.id);
    var index:number;
    for(var coupon of this.coupons){
      if(coupon.id==this.coupon.id){
        index = this.coupons.indexOf(coupon);
      }
    }
    this.coupons[index] = this.coupon;
    // return this.coupons;
    // console.log(Coupons1.item(index).cloneNode());
    // return this.trackByIndex(index,this.coupon);
    this.getAllCompanyCoupons();
  }
    , 100);
  }
  
  getGuestLogin() {
    this.couponService.companyGuestLogin().subscribe(couponService => {
      this.object = couponService;
    })
  }
  getCompanyProfile() {
    this.companyService.getProfile().subscribe(company =>{
      this.company = company;
    });
  }
  getAllCompanyCoupons():Coupon[] {
    this.couponService.getAllCompanyCoupons().subscribe(coupons =>{
      this.coupons = coupons;
    });
    return this.coupons;
  }
  getOneCompanyCoupon(couponId:number):Coupon {
    this.couponService.getOneCompanyCoupon(couponId).subscribe(coupon =>{
      this.coupon = coupon;
    });
    return this.coupon;
  }
  getAllCatagories(){
    this.couponService.getAllCatagories().subscribe(catagory=>{
      this.catagories = catagory;
      console.log(this.catagories);
    });
  }
  
}
