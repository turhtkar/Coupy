import { Component, OnInit, } from '@angular/core';
import { CouponsService } from 'src/app/services/coupons.service';
import { Router } from '@angular/router';
import { Coupon } from 'src/app/models/coupon';
import {formatDate} from '@angular/common';

import { error } from 'util';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  id?: number;
  public companyID?:number;
  public catagory?:string;
  public title?:string;
  public couponDescription?:string; 
  public startDate? = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  public StartDate? = new Date(this.startDate);
  public endDate? = formatDate(new Date(), 'yyyy-MM-dd', 'en');
  public EndDate? = new Date(this.endDate);
  public amount?:number;
  public price?:number;
  public image?:string;
  index: number;
  public currentDiscount: number;
  public currentDate: Date;
  public imageWidth: number;
  public coupon: Coupon;
  coupons:Coupon[]
  catagories:string[]
  object:{}
  value=500;
  selection:string;
  filtered:boolean=false;
  // coupons = new Array();
  // coupons : [{
    //   id : number,
    //   price : number,
    //   image : string,
    // }, {
      //   id : number,
      //   price : number,
      //   image : string,
      // }, {
        //   id : number,
        //   price : number,
        //   image : string,
        // }, {
          //   id : number,
          //   price : number,
          //   image : string,
          // }, {
            //   id : number,
            //   price : number,
            //   image : string,
            // }, {
              //   id : number,
              //   price : number,
              //   image : string,
              // }, {
                // }];
                
                
                
                //  coupon: {id:number,price:number,image:string};
                // image = https://rmhcnashville.com/wp-content/uploads/2017/01/McDs.jpeg"";
                
                constructor(private couponDb:CouponsService, private _router: Router) {
                this.startDate;
                  // this.filtered=false;
                  //   this.coupons = [{
                    //     id : 0,
                    //     price : 1,
                    //     image : "./assets/images/McDonalds.jpeg",
                    //  }, {
                      //     id : 1,
                      //     price : 50,
                      //     image : "./assets/images/burgerKing.jpg",
                      //  }, {
                        //   id : 2,
                        //   price : 50,
                        //   image : "./assets/images/KFC.jpg",
                        // }, {
                          //   id : 3,
                          //   price : 50,
                          //   image : "./assets/images/apple.jpg",
                          // }, {
                            //   id : 4,
                            //   price : 50,
                            //   image : "./assets/images/burgerKing.jpg",
                            // }, {
                              //   id : 5,
                              //   price : 50,
                              //   image : "./assets/images/burgerKing.jpg",
                              // }, {
                                //   id : 6,
                                //   price : 50,
                                //   image : "./assets/images/burgerKing.jpg",
                                //    }];
                              }
                              
                              ngOnInit() {
                                this.coupon = ({id:this.id,companyID:this.companyID,catagory:this.catagory,title:this.title,couponDescription:this.couponDescription,startDate:this.StartDate,endDate:this.EndDate,amount:this.amount,price:this.price,image:this.image});
                                console.log(this.filtered);
                                this.getDbCoupon();
                                this.id = 0;
                                var price = this.price;
                                var image = this.image;
                                this.currentDiscount = 5;
                                this.currentDate = new Date();
                                this.MapGrid();
                                // this.getDbCoupon();
                                // this.getCoupon();
                              }
  // trackByIndex(index: number, obj: any): any{
  // this.index=index;
  // // console.log(this.index);
  //   return index;
  // }
  trackByCouponId(index: number, coupon: any): any{
    if(!coupon) return undefined;
      return coupon.id;
    }
  
  getCoupon(index:number) {
    var i = 0;
    this.coupons[index] = {};
    this.coupon = {};
    return this.coupons.map(coupon=> coupon.image="./assets/images/McDonalds.jpeg", this.coupons[index].image);
    // return this.coupons[index].image="./assets/images/McDonalds.jpeg"
    // return this.coupons[0].image
    // return this.coupon.image=;
  }
  getDbCoupon() {
    this.getGuest();
    this.couponDb.getAllCoupons().subscribe(coupons => {
      this.coupons = coupons;
      this.coupons = this.coupons.map(x=> x, this.coupons);
      this.catagories = this.coupons.map(x=> x.catagory, this.catagories);
      this.catagories = this.catagories.filter((catagory, index) => this.catagories.indexOf(catagory) === index);
      // },err => {
        //   if (err.status === 500) {
          //     this.getGuest();
          //   }
        });
      }
      getOneCoupon(index: number) {
        this.couponDb.getAllCoupons().subscribe(coupons => {
          this.coupons = coupons;
          // coupons.forEach(coupons => {
            //   this.coupon = coupons[index];
            // this.coupons[index] = coupons[index];
            // });
          })}
          
          formatLabel(value: number) {
            if (value >= 1000) {
              return Math.round(value / 1000) + 'k';
            }
        
            return value;
          }
          displayAllCouponsByCatagory(catagory:string):Coupon[] {
            this.couponDb.getAllCouponsForSaleByCatagory(catagory).subscribe(catagory=>{
            this.coupons=catagory;
            });
            return this.coupons;
          }
          displayAllCouponsByPrice(price:number):Coupon[] {
            this.couponDb.getAllCouponsForSaleByPrice(price).subscribe(price=>{
              this.coupons=price;
        
            });
            return this.coupons
          }
          search(selection) {

              if(selection==1) {
        
                  // this.displayAllCouponsByCatagory(this.selectedCoupon.catagory);
                  this.filtered=true;
                  
                  return this.coupons = this.displayAllCouponsByCatagory(this.catagory);
          }
        
              if(selection==2) {
                this.filtered=true;
                return this.coupons = this.displayAllCouponsByPrice(this.value)
        
              }
          }
          clear(){
            this.filtered=false;
            this.couponDb.getAllCoupons().subscribe(coupons => {
              this.coupons = coupons;
            });
          }

          getGuest() {
            this.couponDb.guestLogin().subscribe(coupons => {
              this.object = coupons;
            })}
            getCouponId(index: number) {
              this.coupons[index] = {}; 
              return this.coupons[index].catagory;
            }
            MapGrid() {
              var i:number;
              var newRow:any[] = [];
              var rows:any[][] = [];
              var coulmn:any[] = [];
              let HG = document.getElementsByClassName("HomeGrid") as HTMLCollectionOf<HTMLElement>;
              let HG2 = document.getElementsByClassName("HomeGrid2") as HTMLCollectionOf<HTMLElement>;
              let cS = document.getElementsByClassName("cards") as HTMLCollectionOf<HTMLElement>;
              let cS2 = document.getElementsByClassName("cards2") as HTMLCollectionOf<HTMLElement>;
              let c = document.getElementsByClassName("card") as HTMLCollectionOf<HTMLElement>;

              let HC = document.getElementsByClassName("HomeContainer") as HTMLCollectionOf<HTMLElement>;
              let HC2 = document.getElementsByClassName("HomeContainer2") as HTMLCollectionOf<HTMLElement>;
              cS[0].style.transform="scale(0.8) rotateY(0) translateZ(0)";
              HG[0].style.perspective="0";
              // HG2[0].style.perspective="0"
              HG[0].style.perspectiveOrigin="0";
              // HG2[0].style.perspectiveOrigin="0";

              cS[0].style.transitionDuration="3s";
              cS[0].style.transformStyle="unset";

              // HG2[0].style.display="none";
              
             
            }
            pushCouponOnOpen(index) {
              // this.getOneCoupon(index);
              // console.log("mouseenter" +this.coupons[0].id);
              var newRow1 = new Array(5);
              var i:number;
              var newRow:any[] = [];
              var rows:any[][] = [];
              var coulmn:any[] = [];
              var selectedRow:any[] = [];
              let cardOnOpen = document.getElementsByClassName("HomeContainer") as HTMLCollectionOf<HTMLElement>;
              // let cardBorder = document.getElementsByClassName("card") as HTMLCollectionOf<HTMLElement>;
                // this.coupons = this.coupons.map(x=> x, this.coupons);
                // this.coupon=this.coupons[0];
                // console.log("yeah i am zero");
                // console.log(this.coupons[0]);
                // cardOnOpen[0].style.zIndex = "2";
                // cardOnOpen[0].style.transform = " translatez(110px) scale(1.1, 1.05)"
                // cardOnOpen[0].style.transitionDuration = "0.6s";
                // cardOnOpen[0].style.transition = "1.5"
                // }
                // this.coupon=this.coupons[index];
                if(this.filtered) {
                  cardOnOpen[index].style.zIndex = "2";
                  cardOnOpen[index].style.transform = " translatez(110px) scale(1.1, 1.05)"
                  // cardOnOpen[index].style.transitionDuration = "0.6s";
                  // cardOnOpen[index].style.width = "400px"
                  // cardOnOpen[index].style.height = "500px"
                  cardOnOpen[index].style.transition = "0.5"
                }else{
                this.couponDb.getAllCoupons().subscribe(coupons => {
                  this.coupons = coupons;
                  this.coupon=this.coupons[index];
                  cardOnOpen[index].style.zIndex = "2";
                  cardOnOpen[index].style.transform = " translatez(110px) scale(1.1, 1.05)"
                  // cardOnOpen[index].style.transitionDuration = "0.6s";
                  // cardOnOpen[index].style.width = "400px"
                  // cardOnOpen[index].style.height = "500px"
                  cardOnOpen[index].style.transition = "0.5s"
                });
              }
                }
                // for(i = 0; i<=cardOnOpen.length;i++) {
              //       if(i%5 == 0 && i==index){
                //         newRow = [coulmn1= i-4, coulmn2=i-3, coulmn3=i-2, coulmn4=i-1, coulmn5=i];
                //         rows = [newRow];
                // if(!newRow.includes(i)){
                  //   rows.push(newRow);
                  // }
                  
                  // this.newRow.push(i);
                  
                  // console.log(newRow.toString())
                  
                  // console.log(this.rows.length);
                  // console.log(cardOnOpen.length);
                  // console.log(this.rows.length);
                  
                  // for(let a in newRow) {
                    //   if(newRow.includes(index)) {
                      //     selectedRow = newRow;
          //             for(i = 0; i < cardOnOpen.length; i++) {
          //               // for(var n=i; n<newRow.length*rows.length; n++) {
          //               //   newRow.push(n);
          //               for(i;i<newRow1.length;i++) {
          //                 newRow1.push(i);
          //                 // console.log(newRow1);
          //               }
          //               if(newRow1.length==5) {
          //                   rows.push(newRow1);
          //                   newRow1=[];
          //                   console.log(rows);
          //               }
          //                 // }
              
          //                   for(var a = 0; a<cardOnOpen.length-i; i++) {
          //                     coulmn.push(i);
          //                   }
                          
          //                   // rows.push(coulmn);
          //                   // console.log("leave rows" ,rows)
          //                   //  console.log(rows.length);
          //                   // console.log(coulmn.length);
                            
          //                     // console.log(index%1);
          //                     // iInRow = ((100/((cardOnOpen.length)/b)));
          //                     // selectedRow = ((index/(cardOnOpen.length-1))*(rows.length/100));
          //                     // // console.log(2/((cardOnOpen.length)/b));
                 
          //                     //   var iInRowC= Math.trunc(iInRow);
          //                       for(var row of rows) {
          //                         // console.log(row)
          //                         for(var u of row){

          //                           // if(u=0) {
          //                           //   cardBorder[u].style.borderTopStyle="ridge";
          //                           // }
          //                           console.log("this is row",row);
          //                             if(u!=index && u>index) {
          //                               console.log("bigger");
          //                               cardOnOpen[u].style.marginLeft = "50px"
          //                               cardOnOpen[index].style.transitionDuration = "0.6s";
          //                               cardOnOpen[u].style.transitionDuration = "auto";
                                        
          //                             }
          //                             if(u!=index && u<index) {
          //                               console.log("smaller");
          //                               cardOnOpen[u].style.marginLeft = "-50px"
          //                               cardOnOpen[index].style.transitionDuration = "0.6s";
          //                               cardOnOpen[u].style.transitionDuration = "auto";
          //                             }
          //                           }
          //                         }
          //                       }
          // }
                      
                              
                              //                         for(var c = 0; c < cardOnOpen.length; c++){
                                //                           if(c!=index && c>index) {
                                  //                             cardOnOpen[c].style.marginLeft = "50px"
                                  //                             cardOnOpen[index].style.transitionDuration = "0.6s";
                                  //                           } 
          //                           if(c!=index && c<index) {
            //                             cardOnOpen[c].style.marginRight = "50px"
            //                             cardOnOpen[index].style.transitionDuration = "0.6s";
            //                           }
            //                         }
          // }
        
      
              // if(i!=index && i>index) {
              //   cardOnOpen[i].style.marginLeft = "50px"
              //   cardOnOpen[index].style.transitionDuration = "0.6s";
              // } 
              // if(i!=index && i<index) {
              //   cardOnOpen[i].style.marginRight = "50px"
              //   cardOnOpen[index].style.transitionDuration = "0.6s";
              // }
        // }
      
    
        
    // console.log(newRow);
    // console.log(selectedRow);

    // document.getElementsByClassName("container").style.width = width;
    
  pushCouponOnLeave(index) {
    // this.getOneCoupon(index);
    let cardonLeave = document.getElementsByClassName("HomeContainer") as HTMLCollectionOf<HTMLElement>;
      var i:number;
      var newRow:any[] = [];
      var rows:any[][][] = [];
      var coulmn:any[] = [];
      // cardonLeave[index].style.width = "170px"
      // cardonLeave[index].style.height = "220px"
      cardonLeave[index].style.zIndex = "0"
      cardonLeave[index].style.transform = "scale(0.8, 0.8)"

      // cardonLeave[index].style.width = "300px"
      // cardonLeave[index].style.height = "400px"
      cardonLeave[index].style.transitionDuration = "0.6s";
      cardonLeave[index].style.transitionDuration = "0.4s";
      //  for(i = 0; i < cardonLeave.length; i++) {
        


        for(i = 0; i < cardonLeave.length; i++) {
                        
          for(i = 0; i < 5; i++) {
            newRow.push(i);
          }
          if(newRow.length==5) {
              rows.push(newRow);
          }
          // console.log(rows);
            // }

              for(var a = 0; a<cardonLeave.length-i; i++) {
                coulmn.push(i);
              }
              // rows.push(coulmn);
              // console.log("leave rows" ,rows)
              //  console.log(rows.length);
              // console.log(coulmn.length);
              
                // console.log(index%1);
                // iInRow = ((100/((cardOnOpen.length)/b)));
                // selectedRow = ((index/(cardOnOpen.length-1))*(rows.length/100));
                // // console.log(2/((cardOnOpen.length)/b));
   
                //   var iInRowC= Math.trunc(iInRow);
                  for(var row of rows) {
                    // console.log(row)
                    for(var u of newRow){
                      // if(u=0) {
                      //   cardBorder[u].style.borderTopStyle="ridge";
                      // }



                      // on change row


        // if(u!=index && u>index) {
        //   cardonLeave[u].style.marginLeft = "5px"
        //   cardonLeave[index].style.transitionDuration = "0.6s";
        //   cardonLeave[u].style.transitionDuration = "auto"

        // } 
        // if(u!=index && u<index) {
        //   // console.log("smallerPRob");
        //   cardonLeave[u].style.marginLeft = "-5px"
        //   cardonLeave[index].style.transitionDuration = "0.6s";
        //   cardonLeave[u].style.transitionDuration = "auto"

        // }
      }
    }
  }
}
        navigateToItem(index){
          //do your any operations
          var i:number;
          let cardonLeave = document.getElementsByClassName("HomeContainer") as HTMLCollectionOf<HTMLElement>;
          let itemOnEnter = document.getElementsByClassName("ItemContainer") as HTMLCollectionOf<HTMLElement>;
          let cards = document.getElementsByClassName("cards") as HTMLCollectionOf<HTMLElement>;
          for(i = 0; i < cardonLeave.length; i++) {
            //LeftAnimation
            // if(i!=index && i>index) {
            if(index%5<i%5) {
              cardonLeave[index].style.animationName = "navigateRight"
              cardonLeave[index].style.animationDuration = "1s";
              // cardonLeave[i].style.animationName = "navigateRight"
              // cardonLeave[i].style.animationDuration = "1s";
            }
            //RightAnimation
            // if(i!=index && i<index) {
              if(index%5>i%5) {
              
              cardonLeave[index].style.animationName = "navigateLeft"
              // cardonLeave[index].style.animationName = "navigateRight"
              cardonLeave[index]
              cardonLeave[index].style.animationDuration = "1s";
              // cardonLeave[i].style.animationName = "navigateLeft"
              // cardonLeave[i].style.animationDuration = "1s";

            }
            setTimeout(() => {
              this.coupon=this.coupons[index];

              cards[0].style.display = "none"
              // cards[0].remove();
              itemOnEnter[0].style.display = "flex";

              // this._router.navigate(['login']);

            }
            , 1000);
          }
            // this._router.navigate(['login']);
        }
        purcheseCoupon(purchesedCoupon:Coupon) {
          this.couponDb.purcheseCoupon(purchesedCoupon).subscribe(coupon =>{
            this.coupon=purchesedCoupon;
            alert("{\Successful\":\"You've purchesed Coupon\"}" +coupon.title + " a recpit for your purchese will soon be sent to you through your email\n ty for shopping at Coupy and have a Good Day :D");

          })
        }
        onClickedOutsideItem() {
          let itemOnEnter = document.getElementsByClassName("ItemContainer") as HTMLCollectionOf<HTMLElement>;
          let cards = document.getElementsByClassName("cards") as HTMLCollectionOf<HTMLElement>;
          cards[0].style.display = "flex";
          // cards[0].classList.add();
          itemOnEnter[0].style.display = "none";
        }
}
