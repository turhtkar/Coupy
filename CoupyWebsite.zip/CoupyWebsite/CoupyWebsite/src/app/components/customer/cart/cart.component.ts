import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/coupon';
import { CouponsService } from 'src/app/services/coupons.service';
import { Observable } from 'rxjs';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { Catagory } from 'src/app/models/catagory';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  form: FormGroup;
  public coupon: Coupon;
  public coupons:Coupon[];
  catagories:string[];

  columns: string[] = [];
  imgColumn: string[] =[];
  index:number;
  selection:string;
  value=500;
  catagory?:string;
  images:string[] = [];
  constructor(private couponDb:CouponsService,private formBuilder: FormBuilder) {
    // this.coupons=new Array<Coupon>();
    // this.coupons=this.getPurchesedCoupon()
    this.getPurchesedCoupon();
    // this.catagories = this.getPurchesedCoupon().map(coupon => coupon.catagory, this.catagories);
    for(let i=0; i<this.columns.length; i++)
    {
       this.images[i] = this.coupon.image;
    }
  }
  ngOnInit() {
    this.imgColumn=["image"];
    this.columns = ["image","couponDescription","price", "amount"];
    console.log(this.columns);
    this.getPurchesedCoupon();
}
  getPurchesedCoupon():Coupon[] {
    
    this.couponDb.getAllPurchesedCoupons().subscribe(coupons => {
      this.coupons = coupons;
      this.catagories = this.coupons.map(x=> x.catagory, this.catagories);
      this.images = this.coupons.map(x=> x.image, this.images);

      // },err => {
        //   if (err.status === 500) {
          //     this.getGuest();
          //   }
        });
        return this.coupons;
        // return this.coupons;
      }

  getCouponImage() {
    let image = document.getElementsByClassName("td") as HTMLCollectionOf<HTMLElement>;
   this.coupon.couponDescription
    console.log(image)
    for(var i=0;i<image.length;i++) {
      
      // image[i].style.backgroundImage = "url(https://images.pexels.com/photos/414612/pexels-photo-414612.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500)"
      console.log(this.coupon);
      image[i].style.fontSize ="30px";

    }
  }
  formatLabel(value: number) {
    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }
  displayAllCouponsByCatagory(catagory:string):Coupon[] {
    this.couponDb.getAllPurchesedCouponsByCatagory(catagory).subscribe(catagory=>{
    this.coupons=catagory;
    });
    return this.coupons;
  }
  displayAllCouponsByPrice(price:number):Coupon[] {
    this.couponDb.getAllPurchesedCouponsByPrice(price).subscribe(price=>{
      this.coupons=price;

    });
    return this.coupons
  }
  search(selection) {
    // this.catagories = this.getPurchesedCoupon().map(x => x.catagory, this.catagories);

      if(selection==1) {
        console.log("1")

          // this.displayAllCouponsByCatagory(this.selectedCoupon.catagory);

          return this.coupons = this.displayAllCouponsByCatagory(this.catagory);
  }

      if(selection==2) {
        console.log("2")
        console.log(this.displayAllCouponsByPrice(this.value));
        return this.coupons = this.displayAllCouponsByPrice(this.value)

      }
  }
 
  indexTracker(index: number, value: any){
    // console.log(index + " " + value);
    return index;
  }
}
