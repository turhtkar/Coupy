import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/coupon';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';
import { CouponsService } from 'src/app/services/coupons.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  couponsFilterControl=new FormControl();
  filteredOptions: Observable<Coupon[]>;
  public coupon: Coupon;
  public coupons:Coupon[];
  constructor(private couponService: CouponsService) { 
    this.coupons= new Array<Coupon>();
  }

  ngOnInit() {
    this.getAllCompanyCoupons();

    this.filteredOptions = this.couponsFilterControl.valueChanges
    .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.title),
      map(title =>title ? this._filter(title): this.coupons.slice())
    );
  }
  getAllCompanyCoupons() {
    this.couponService.getAllCompanyCoupons().subscribe(coupns =>{
      this.coupons = coupns;
    });
  }

  displayFn(coupon?: Coupon): string | undefined {
    return coupon ? coupon.title : undefined;
  }
  
  private _filter(value: string): Coupon[] {
    const filterValue = value.toLowerCase();
  
      return this.coupons.filter(coupon => coupon.title.toLowerCase().indexOf(filterValue) === 0);
  }

}
