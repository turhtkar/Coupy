import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from './app-routing.module';
import { LayoutComponent } from './components/layout/layout.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { MenuComponent } from './components/menu/menu.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { LoginComponent } from './components/login/login.component';
import { AboutComponent } from './components/about/about.component';
import { AdminComponent } from './components/admin/admin.component';
import {MatCardModule, MatButtonModule} from '@angular/material'
import { FlexLayoutModule } from "@angular/flex-layout";
import { ScrollingModule } from '@angular/cdk/scrolling'
import {MatFormFieldModule} from '@angular/material/form-field';




import { LoginValidatorService } from './services/login-validator.service';
import { AdminGuard } from './guards/admin.guard';
import { AuthService } from './guards/auth.service';
import { CompanyComponent } from './components/company/company.component';
import { FilterPipe } from './filter.pipe';
import { CatagoryComponent } from './models/catagory/catagory.component';
import { CouponsFilterPipe } from './pipes/coupons-filter.pipe';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatAutocompleteModule,MatInputModule} from '@angular/material';
import {MatSelectModule} from '@angular/material/select';
import { MatCommonModule, MatOptionModule } from '@angular/material/core';
import { ResetSearchPipe } from './pipes/reset-search.pipe';
import {MatRadioModule} from '@angular/material/radio';
import {MatSliderModule} from '@angular/material/slider'
import { CartComponent } from './components/customer/cart/cart.component';
import { CustomerFilterPipe } from './pipes/customer-filter.pipe';




@NgModule({
  declarations: [
    LayoutComponent, 
    HeaderComponent, 
    FooterComponent, 
    MenuComponent, 
    HomeComponent, LoginComponent, AboutComponent, AdminComponent, CompanyComponent, FilterPipe, CatagoryComponent, CouponsFilterPipe, ResetSearchPipe, CartComponent, CustomerFilterPipe,
    ],
  imports: [BrowserModule,
     AppRoutingModule, 
     FormsModule,
     ReactiveFormsModule, 
     HttpClientModule,
     MatCardModule, 
     MatButtonModule, 
     FlexLayoutModule,
     ScrollingModule,
     BrowserAnimationsModule,
     MatAutocompleteModule,
     MatInputModule,
     MatFormFieldModule,
     MatSelectModule,
     MatOptionModule,
     MatCommonModule,
     MatRadioModule,
     MatSliderModule,
    ],
  providers: [LoginValidatorService, AdminGuard, AuthService],
  bootstrap: [LayoutComponent]
})
export class AppModule { }
