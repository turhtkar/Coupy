export class Income {

    constructor(
        public id?:number,
        public name?:string,
        public transactionDate?:Date,
        public description?:string,
        public amount?:number,
        public clientID?:string
    ){

    }
}
