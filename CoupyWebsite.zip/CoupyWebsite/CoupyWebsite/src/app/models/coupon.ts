import { Deserializable } from './deserializable';

export class Coupon  {

    constructor(
        public id?:number,
        public companyID?:number, 
        public catagory?:string,
        public title?:string,
        public couponDescription?:string, 
        public startDate?:Date,
        public endDate?:Date,
        public amount?:number,
        public price?:number,
        public image?:string,   
    ) {


        
    }

    // deserialize(input: any): this {
    //     return Object.assign(this, input);
    // }
}
