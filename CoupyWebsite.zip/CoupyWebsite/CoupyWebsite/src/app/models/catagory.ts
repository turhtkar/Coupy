export class Catagory {


    constructor(
    public id?:number,
    public name?:string,
    ) {

    }
}
