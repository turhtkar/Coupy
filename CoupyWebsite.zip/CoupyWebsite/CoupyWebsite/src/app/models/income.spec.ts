import { Income } from './income';

describe('Income', () => {
  it('should create an instance', () => {
    expect(new Income()).toBeTruthy();
  });
});
