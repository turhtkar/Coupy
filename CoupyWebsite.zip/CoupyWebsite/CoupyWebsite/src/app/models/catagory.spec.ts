import { Catagory } from './catagory';

describe('Catagory', () => {
  it('should create an instance', () => {
    expect(new Catagory()).toBeTruthy();
  });
});
