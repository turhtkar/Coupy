import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer } from '../models/customer';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {


  
  constructor(private http:HttpClient) {
  }
  getAllCustomers():Observable<Customer[]> {
    return this.http.get<Customer[]>("http://localhost:8080/Coupy/api/admin/customers", this.httpOptions);
  }
  createCustomer(customer: any):Observable<Customer> {
    return this.http.post<Customer>("http://localhost:8080/Coupy/api/admin/customers", customer, this.httpOptions);
  }
  getOneCustomer(customer: Customer) {
    return this.http.get<Customer>("http://localhost:8080/Coupy/api/admin/customers/"+customer.id, this.httpOptions);
  }
  updateCustomer(customer: any):Observable<Customer> {
    return this.http.put<Customer>("http://localhost:8080/Coupy/api/admin/customers/"+customer.id, customer, this.httpOptions);
  }
  deleteCustomer(customerId:number):Observable<Customer> {
    return this.http.delete<Customer>("http://localhost:8080/Coupy/api/admin/customers/"+customerId, this.httpOptions);
  }



      httpOptions = {
        headers: new HttpHeaders({
        'Content-Type': 'application/json;charset=utf-8',
        'withCredentials': 'true'
      }),
    };
  }
