import { TestBed } from '@angular/core/testing';

import { LoginValidatorService } from './login-validator.service';

describe('LoginValidatorService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LoginValidatorService = TestBed.get(LoginValidatorService);
    expect(service).toBeTruthy();
  });
});
