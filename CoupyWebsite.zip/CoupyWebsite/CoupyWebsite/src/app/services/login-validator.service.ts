import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LoginValidatorService {

  ClientPath: string;
  isLoggedIn: boolean;
  req = this.http;

  firstClick() {
    return console.log('clicked');
  }
  constructor(private http: HttpClient, private _router: Router) { 
  }
  
  
  
  LoginController(client:{email?:string, password?:string, clientType?:string}) {
    switch(client.clientType) {
                case "CUSTOMER": 
                this.ClientPath = "http://localhost:8080/Coupy/api/customer/login/"+client.email+"/"+client.password;
                  return this.http.get(this.ClientPath,{withCredentials:true})
                  
                break;
                case "COMPANY":
                  this.ClientPath = "http://localhost:8080/Coupy/api/company/login/"+client.email+"/"+client.password;
                  console.log("Company");
                  return this.http.get(this.ClientPath, {withCredentials:true})
                   
                  break;
                  case "ADMIN":
                    this.ClientPath = "http://localhost:8080/Coupy/api/admin/login/"+client.email+"/"+client.password;
                     return this.http.get(this.ClientPath, {withCredentials:true})
                      break;
                    }
                    this.ClientPath = "http://localhost:8080/Coupy/api/admin/login/"+client.email+"/"+client.password;
                     this.http.get(this.ClientPath, {withCredentials:true})
                  }
                   httpOptions = {
                    headers: new HttpHeaders({
                      // 'Content-Type':  'application/json;charset=utf-8',
                      // 'Authorization': 'my-auth-token',
                        //'Access-Control-Allow-Origin' : 'http://localhost:4200/login',
                        // 'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
                        // 'Access-Control-Allow-Headers': 'Origin, Content-Type, X-Auth-Token',
                      

                    })
                  };
                  
                  
  }
  
  
  