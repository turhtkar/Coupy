import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Company } from '../models/company';


@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  // company:Company;
  // body: {id: number,
  //   name:string,
  //   email:string,
  //   password:string};
    constructor(private http: HttpClient) { 
    
  }
  
  createCompany(company:any): Observable<Company> {
    return this.http.post<Company>("http://localhost:8080/Coupy/api/admin/companies", company, this.httpOptions );
  }
  getAllCompanies(): Observable<Company[]> {
    return this.http.get<Company[]>("http://localhost:8080/Coupy/api/admin/companies", this.httpOptions);
  }
  updateCompany(company: Company): Observable<Company> {
    return this.http.put<Company>("http://localhost:8080/Coupy/api/admin/companies/"+company.id, company, this.httpOptions);
  }
  getOneCompany(company:Company) {
    return this.http.get("http://localhost:8080/Coupy/api/admin/companies/"+company.id, this.httpOptions);
  }
  deleteCompany(company: Company):Observable<Company> {
    let httpOptionsDelete = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json;charset=utf-8',
        'withCredentials': 'true'
      }),
      body: {id: company.id,
        name: company.name,
        email: company.email,
        password: company.password}
      };
      return this.http.delete<Company>("http://localhost:8080/Coupy/api/admin/companies",httpOptionsDelete);
    }
    getProfile():Observable<Company> {
     return this.http.get<Company>("http://localhost:8080/Coupy/api/company/user/", this.httpOptions);
    }
    
    
    
    httpOptions = {
      headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=utf-8',
      'withCredentials': 'true'
    }),
  };
  // httpOptionsDelete = {
  //   headers: new HttpHeaders({
  //     'Content-Type': 'application/json;charset=utf-8',
  //     'withCredentials': 'true'
  //   }),
  //   body: this.body
  //   };
  


//   {observe:{"id":company.id.toString(),
//     "name":company.name.toString(),
//     "email":company.email.toString(),
//     "password":company.password.toString()});
// }
}
