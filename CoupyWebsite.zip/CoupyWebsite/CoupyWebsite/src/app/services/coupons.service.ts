import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { response } from 'express';
import { Observable } from 'rxjs';
import { Coupon } from '../models/coupon';
import {map} from 'rxjs/operators';
import { Catagory } from '../models/catagory';
import { Income } from '../models/income';


@Injectable({
  providedIn: 'root'
})
export class CouponsService {
  
  
  

  constructor(private http: HttpClient, private _router: Router) { 
    
  }
  coupon:{COUPON_ID?:number, COMPANY_ID?:number, CATAGORY?:string, TITLE?:string, DESCRIPTION?:string, START_DATE?:Date, END_DATE?:Date, AMOUNT?:number, PRICE?:number, IMAGE?:string}
  getCoupons(coupon:{COUPON_ID?:number, COMPANY_ID?:number, CATAGORY?:string, TITLE?:string, DESCRIPTION?:string, START_DATE?:Date, END_DATE?:Date, AMOUNT?:number, PRICE?:number, IMAGE?:string}    ) {
    return this.http.get("http://localhost:8080/Coupy/api/customer/getAllCoupons" ,{withCredentials:true});
    // return response.json(this.coupon);
  }
  getAllCouponsForSaleByCatagory(catagory: string):Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/getAllCoupons/4Sale/byCatagory/"+catagory, this.httpOptions);
  }
  getAllCouponsForSaleByPrice(price: number): Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/getAllCoupons/4Sale/byPrice/"+price, this.httpOptions);
  }
  getAllCoupons(): Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/getAllCoupons", this.httpOptions);
  }
  guestLogin() {
    return this.http.get("http://localhost:8080/Coupy/api/customer/login/CouponShop@gmail.com/1234", {withCredentials:true});
  }
  companyGuestLogin() {
    return this.http.get("http://localhost:8080/Coupy/api/company/login/aa@gmail.com/1234", {withCredentials:true});
  }
  addCoupon(coupon:any): Observable<Coupon> {
    return this.http.post<Coupon>("http://localhost:8080/Coupy/api/company/coupons", coupon, this.httpOptions);
    
  }
  getOneCompanyCoupon(couponId: number): Observable<Coupon> {
    return this.http.get<Coupon>("http://localhost:8080/Coupy/api/company/coupons/"+couponId, this.httpOptions);

  }
  updateCoupon(coupon: any): Observable<Coupon> {
    return this.http.put<Coupon>("http://localhost:8080/Coupy/api/company/coupons/"+coupon.id, coupon, this.httpOptions);
  }
  removeCoupon(couponToRemove: Coupon): Observable<Coupon> {
    let httpOptionsDelete = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json;charset=utf-8',
        'withCredentials': 'true'
      }),
      body: {id: couponToRemove.id,
        companyID: couponToRemove.companyID,
        catagory: couponToRemove.catagory,
        title: couponToRemove.title,
        couponDescription: couponToRemove.couponDescription,
        startDate: couponToRemove.startDate,
        endDate: couponToRemove.endDate,
        amount: couponToRemove.amount,
        price: couponToRemove.price,
        image: couponToRemove.image}
      };
    return this.http.delete<Coupon>("http://localhost:8080/Coupy/api/company/coupons", httpOptionsDelete );
  
  }
  getAllCompanyCoupons():Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/company/coupons/CompanyCoupons/", this.httpOptions);
  }
  getAllCatagories(): Observable<Catagory[]> {
    return this.http.get<Catagory[]>("http://localhost:8080/Coupy/api/company/coupons/Catagories/", this.httpOptions);
  }
  getAllPurchesedCoupons(): Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/Cart",this.httpOptions);
  }
  getAllPurchesedCouponsByCatagory(catagory: string):Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/Cart/byCatagory/"+catagory,this.httpOptions);
    
  }
  getAllPurchesedCouponsByPrice(price: number):Observable<Coupon[]> {
    return this.http.get<Coupon[]>("http://localhost:8080/Coupy/api/customer/Cart/byPrice/"+price,this.httpOptions);

  }
      
  purcheseCoupon(coupon:any): Observable<Coupon> {
    return this.http.post<Coupon>("http://localhost:8080/Coupy/api/customer/Cart", coupon,this.httpOptions);
  }
  getAllIncomes():Observable<Income[]> {
    return this.http.get<Income[]>("http://localhost:8080/Coupy/api/admin/incomes", this.httpOptions);
  }
  getAllCustomerIncomes(customerID: number): Observable<Income[]> {
    return this.http.get<Income[]>("http://localhost:8080/Coupy/api/admin/customer/incomes/"+customerID, this.httpOptions);  
  }
  getAllCompanyIncomes(companyID: number): Observable<Income[]> {
    return this.http.get<Income[]>("http://localhost:8080/Coupy/api/admin/company/incomes/"+companyID, this.httpOptions);  
  }
  getAllIncomeBy():Observable<Income[]> {
    return this.http.get<Income[]>("http://localhost:8080/Coupy/api/company/incomes/", this.httpOptions);  
  }
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json;charset=utf-8',
      'withCredentials': 'true'
    })
  };
     

}
