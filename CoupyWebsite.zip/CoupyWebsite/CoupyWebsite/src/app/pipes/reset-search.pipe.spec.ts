import { ResetSearchPipe } from './reset-search.pipe';

describe('ResetSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ResetSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
