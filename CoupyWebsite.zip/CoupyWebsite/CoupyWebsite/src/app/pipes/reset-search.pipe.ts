import { Pipe, PipeTransform } from '@angular/core';
import { Coupon } from '../models/coupon';


@Pipe({
  name: 'resetSearch'
})
export class ResetSearchPipe implements PipeTransform {

  transform(SearchCoupon: string, ResetSearch:boolean): any {

    if (!SearchCoupon) {
      console.log(ResetSearch);
      return ResetSearch==true;
      
    }
    if(!ResetSearch)
    console.log(SearchCoupon)
    return SearchCoupon;
  
    }
    // searchText = searchText.toLocaleLowerCase();

    // return coupons.filter(it => {
    //   return it.title.includes(searchText)||it.catagory.includes(searchText);
    // });
}
