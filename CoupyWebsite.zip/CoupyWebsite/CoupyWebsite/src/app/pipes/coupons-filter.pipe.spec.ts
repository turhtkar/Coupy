import { CouponsFilterPipe } from './coupons-filter.pipe';

describe('CouponsFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CouponsFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
