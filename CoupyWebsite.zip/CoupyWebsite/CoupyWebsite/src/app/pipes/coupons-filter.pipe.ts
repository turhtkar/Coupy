import { Pipe, PipeTransform } from '@angular/core';
import { Coupon } from '../models/coupon';

@Pipe({
  name: 'couponsFilter'
})
export class CouponsFilterPipe implements PipeTransform {

  transform(coupons: Coupon[], searchText: string): any {
    if (!coupons) {
      return [];
    }
    if (!searchText) {
      return coupons;
    }
    // searchText = searchText.toLocaleLowerCase();

    return coupons.filter(it => {
      return it.title.includes(searchText)||it.catagory.includes(searchText);
    });
  }

}
