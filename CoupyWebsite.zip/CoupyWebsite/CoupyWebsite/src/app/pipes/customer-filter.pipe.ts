import { Pipe, PipeTransform } from '@angular/core';
import { Customer } from '../models/customer';

@Pipe({
  name: 'customerFilter'
})
export class CustomerFilterPipe implements PipeTransform {

  transform(customers: Customer[], searchText: string): any {
    if (!customers) {
      return [];
    }
    if (!searchText) {
      return customers;
    }
    searchText = searchText.toLocaleLowerCase();

    return customers.filter(it => {
      return it.firstName.includes(searchText) || it.lastName.includes(searchText);
    });
  }

}
