import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminGuard } from './guards/admin.guard';
import { CompanyComponent } from './components/company/company.component';
import { CartComponent } from './components/customer/cart/cart.component';


const routes: Routes = [
  //{path: "admin/login/:email/:password", component: LoginComponent}
  {path: '', redirectTo: '/home', pathMatch: 'full'},
  {path: '**', redirectTo: '*'},
  {path: 'home', component: HomeComponent},
  {path: 'about', component: AboutComponent},
  {path: 'login', component: LoginComponent},
  {path: 'company', component: CompanyComponent},
  {path: 'cart', component: CartComponent},
  {path: 'admin',
  component: AdminComponent, canActivate: [AdminGuard],
  children: [
      {
          path: 'list',
          component: AdminComponent,
          canActivate: [AdminGuard]
      },            
      {
          path: 'create',
          component: AdminComponent,
          canActivate: [AdminGuard]
      },
      {
          path: 'update',
          component: AdminComponent,
          canActivate: [AdminGuard]
      },
]}]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  constructor(private router: Router) {}



getAdminUi() {
  this.router.navigate(['/admin']);
 }
}