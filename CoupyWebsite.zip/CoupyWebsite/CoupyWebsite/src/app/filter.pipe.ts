import { Pipe, PipeTransform } from '@angular/core';
import { Company } from './models/company';
import { Coupon } from './models/coupon';

@Pipe({
  name: 'filter'
})
// 
export class FilterPipe implements PipeTransform {

  transform(companies: Company[], searchText: string): any {
    if (!companies) {
      return [];
    }
    if (!searchText) {
      return companies;
    }
    searchText = searchText.toLocaleLowerCase();

    return companies.filter(it => {
      return it.name.includes(searchText);
    });
  }

}
